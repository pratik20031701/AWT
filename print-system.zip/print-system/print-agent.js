/**
 * Print Agent — runs on the shop PC
 * Usage: node print-agent.js S01 http://localhost:3000
 */
require('dotenv').config();
const axios        = require('axios');
const fs           = require('fs');
const path         = require('path');
const { exec }     = require('child_process');

const SHOP_ID    = process.argv[2] || 'S01';
const SERVER_URL = process.argv[3] || 'http://localhost:3000';
const TEMP_DIR   = './temp_prints';
const POLL_MS    = 5000;

let detectedPrinter = null;
let printerAvailable = false;

if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

console.log(`\n🖨️  Print Agent started`);
console.log(`   Shop:   ${SHOP_ID}`);
console.log(`   Server: ${SERVER_URL}\n`);

// ── Detect available printers ────────────────────────────────────
function getAvailablePrinters() {
  return new Promise(resolve => {
    exec('lpstat -a 2>/dev/null', (err, stdout) => {
      if (err || !stdout.trim()) return resolve([]);
      const printers = stdout.split('\n')
        .filter(l => l.trim())
        .map(l => l.split(/\s+/)[0])
        .filter(Boolean);
      resolve(printers);
    });
  });
}

// ── Update shop printer status on server ─────────────────────────
async function updateShopStatus(status) {
  try {
    await axios.put(`${SERVER_URL}/api/shops/${SHOP_ID}`, {
      printer_status: status
    });
  } catch (e) {
    console.error('   Failed to update shop status:', e.message);
  }
}

// ── Check printer and update server ──────────────────────────────
async function checkPrinterStatus() {
  const printers = await getAvailablePrinters();
  
  if (printers.length > 0) {
    detectedPrinter = printers[0];
    printerAvailable = true;
    console.log(`✅ Printer detected: ${detectedPrinter}`);
    await updateShopStatus('online');
  } else {
    printerAvailable = false;
    console.log(`⚠️  No printer detected — printer status set to OFFLINE`);
    await updateShopStatus('offline');
  }
}

// ── Print a file ─────────────────────────────────────────────────
async function printFile(filePath, copies, doubleSided) {
  // Check if printer is available
  if (!printerAvailable || !detectedPrinter) {
    throw new Error('Printer is offline - no printer available');
  }

  // Windows
  if (process.platform === 'win32') {
    return new Promise((resolve, reject) => {
      exec(`PDFtoPrinter.exe "${filePath}"`, err => err ? reject(err) : resolve());
    });
  }

  // macOS / Linux — send to detected printer
  console.log(`   🖨️  Sending to: ${detectedPrinter}`);
  let cmd = `lpr -P "${detectedPrinter}" -#${copies} "${filePath}"`;
  if (doubleSided) cmd += ' -o sides=two-sided-long-edge';

  return new Promise((resolve, reject) => {
    exec(cmd, err => err ? reject(err) : resolve());
  });
}

// ── Update job status on server ──────────────────────────────────
async function updateStatus(requestId, status, error) {
  try {
    await axios.post(`${SERVER_URL}/api/print/${requestId}/status`, { status, error });
  } catch (e) {
    console.error('   Failed to update job status:', e.message);
  }
}

// ── Main poll loop ───────────────────────────────────────────────
async function poll() {
  try {
    // Don't fetch jobs if printer is offline
    if (!printerAvailable) {
      setTimeout(poll, POLL_MS);
      return;
    }

    const res = await axios.get(
      `${SERVER_URL}/api/print/${SHOP_ID}/stream`,
      { responseType: 'stream' }
    );

    const requestId  = res.headers['x-request-id'];
    const pages      = res.headers['x-pages'];
    const copies     = res.headers['x-copies'];
    const mode       = res.headers['x-mode'];
    const doubleSide = res.headers['x-double-sided'] === 'true';

    console.log(`\n📄 New job: ${requestId}`);
    console.log(`   Pages:${pages}  Copies:${copies}  Mode:${mode}  DoubleSided:${doubleSide}`);

    const filePath = path.join(TEMP_DIR, `${requestId}.pdf`);
    const writer   = fs.createWriteStream(filePath);
    res.data.pipe(writer);

    writer.on('finish', async () => {
      console.log('   File received — sending to printer...');
      try {
        await printFile(filePath, parseInt(copies) || 1, doubleSide);
        await updateStatus(requestId, 'completed');
        fs.unlink(filePath, () => {});
        console.log(`   ✅ Printed successfully!\n`);
      } catch (printErr) {
        console.error(`   ❌ Print failed: ${printErr.message}`);
        await updateStatus(requestId, 'failed', printErr.message);
        // Keep the file for later when printer comes online
        console.log(`   📁 File saved at: ${filePath}\n`);
      }
      setTimeout(poll, 1000);
    });

    writer.on('error', async err => {
      console.error('   ❌ File write error:', err.message);
      await updateStatus(requestId, 'failed', err.message);
      setTimeout(poll, POLL_MS);
    });

  } catch (err) {
    if (err.response?.status === 404) {
      // No pending jobs — normal, keep polling silently
    } else {
      console.error('Poll error:', err.message);
    }
    setTimeout(poll, POLL_MS);
  }
}

// ── Start ────────────────────────────────────────────────────────
(async () => {
  await checkPrinterStatus();
  console.log('\n🔄 Starting job polling...\n');
  poll();
  
  // Re-check printer status every 60 seconds
  setInterval(checkPrinterStatus, 60000);
})();

process.on('SIGINT', async () => {
  console.log('\n👋 Print agent stopped');
  await updateShopStatus('offline');
  process.exit(0);
});
