const db = require('../config/db');
const queueService = require('../services/queueService');

exports.getQueue = (req, res) => {
  const jobs = queueService.getQueue(req.params.shopId);
  res.json({ success: true, data: jobs });
};

exports.getPosition = (req, res) => {
  const pos = queueService.getPosition(req.params.requestId);
  if (pos === null) return res.status(404).json({ error: 'Job not found' });
  res.json({ success: true, data: { requestId: req.params.requestId, position: pos } });
};

exports.streamJob = (req, res) => {
  try {
    const job = queueService.getNextJob(req.params.shopId);
    if (!job) return res.status(404).json({ error: 'No pending jobs' });

    const stream = queueService.streamJob(job.request_id);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('X-Request-ID', job.request_id);
    res.setHeader('X-Pages', job.pages);
    res.setHeader('X-Copies', job.copies);
    res.setHeader('X-Mode', job.mode);
    res.setHeader('X-Double-Sided', job.double_sided);
    stream.pipe(res);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateStatus = (req, res) => {
  const { status, error } = req.body;
  const job = queueService.updateStatus(req.params.requestId, status, error);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json({ success: true, data: job });
};

exports.pauseQueue = (req, res) => {
  db.update('shops', { shop_id: req.params.shopId }, {
    printer_status: req.body.reason || 'paused'
  });
  res.json({ success: true, message: 'Queue paused' });
};

exports.resumeQueue = (req, res) => {
  db.update('shops', { shop_id: req.params.shopId }, { printer_status: 'online' });
  res.json({ success: true, message: 'Queue resumed' });
};
