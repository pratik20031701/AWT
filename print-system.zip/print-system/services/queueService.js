const db = require('../config/db');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

function getNextPosition(shopId) {
  const active = db.findAll('queue', { shop_id: shopId }).filter(j =>
    ['pending', 'printing'].includes(j.status)
  );
  if (!active.length) return 1;
  return Math.max(...active.map(j => j.position)) + 1;
}

function addJob(shopId, uploadId, paymentId, filePath, pages, mode, copies, doubleSided) {
  const position = getNextPosition(shopId);
  return db.insert('queue', {
    request_id: uuidv4(),
    shop_id: shopId,
    upload_id: uploadId,
    payment_id: paymentId,
    file_path: filePath,
    pages,
    mode,
    copies,
    double_sided: doubleSided,
    position,
    status: 'pending'
  });
}

function getQueue(shopId) {
  return db.findAll('queue', { shop_id: shopId })
    .sort((a, b) => a.position - b.position);
}

function getPosition(requestId) {
  const job = db.findOne('queue', { request_id: requestId });
  if (!job) return null;
  const ahead = db.findAll('queue', { shop_id: job.shop_id }).filter(j =>
    ['pending', 'printing'].includes(j.status) && j.position < job.position
  );
  return ahead.length + 1;
}

function getNextJob(shopId) {
  const shop = db.findOne('shops', { shop_id: shopId });
  if (!shop || shop.printer_status !== 'online') return null;
  const pending = db.findAll('queue', { shop_id: shopId, status: 'pending' })
    .sort((a, b) => a.position - b.position);
  return pending[0] || null;
}

function updateStatus(requestId, status, errorMsg = null) {
  const changes = { status };
  if (status === 'printing') changes.started_at = new Date().toISOString();
  if (status === 'completed') changes.completed_at = new Date().toISOString();
  if (errorMsg) changes.error = errorMsg;

  const job = db.update('queue', { request_id: requestId }, changes);

  // Delete file after completion
  if (status === 'completed' && job) {
    try { fs.unlinkSync(job.file_path); } catch {}
  }
  return job;
}

function streamJob(requestId) {
  const job = db.findOne('queue', { request_id: requestId });
  if (!job) throw new Error('Job not found');
  if (job.status !== 'pending') throw new Error('Job is not pending');
  db.update('queue', { request_id: requestId }, {
    status: 'printing',
    started_at: new Date().toISOString()
  });
  return fs.createReadStream(job.file_path);
}

module.exports = { addJob, getQueue, getPosition, getNextJob, updateStatus, streamJob };
